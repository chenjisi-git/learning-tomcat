package server;

import server.mapper.HostMapper;

import java.io.InputStream;
import java.net.Socket;
import java.util.Map;

public class RequestProcessor extends Thread {

    private Socket socket;
    private Map<String,HttpServlet> servletMap;
    private HostMapper hostMapper;
    private String contextPath;

    public RequestProcessor(Socket socket, HostMapper hostMapper) {
        this.socket = socket;
        this.hostMapper = hostMapper;
    }

    @Override
    public void run() {
        try{
            InputStream inputStream = socket.getInputStream();
            // 封装Request对象和Response对象
            Request request = new Request(inputStream);
            System.out.println(request);
            Response response = new Response(socket.getOutputStream());
            String[] urlPaths=request.getUrl().split("/");
            contextPath=urlPaths[1];
            request.setUrl("/"+urlPaths[2]);
            servletMap=hostMapper.getContextMapperMap().get(contextPath).getWrapperMapper().getServletMapperMap();
            // 静态资源处理
            if(servletMap.get(request.getUrl()) == null) {
                response.outputHtml(request.getUrl());
            }else{
                // 动态资源servlet请求
                HttpServlet httpServlet = servletMap.get(request.getUrl());
                httpServlet.service(request,response);
            }

            socket.close();

        }catch (Exception e) {
            e.printStackTrace();
        }

    }
}
