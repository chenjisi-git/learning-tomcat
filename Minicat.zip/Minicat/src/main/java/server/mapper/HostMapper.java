package server.mapper;

import java.util.HashMap;
import java.util.Map;

/**
 * @author aleng
 * @version 1.0.0
 * @className MappedHost
 * @description TODO
 * @createTime 2020年06月01日 19:54:00
 */
public class HostMapper {

  private Map<String,ContextMapper> contextMapperMap=new HashMap<>();

  public HostMapper() {
  }

  public Map<String,ContextMapper>  getContextMapperMap() {
    return contextMapperMap;
  }

  public void setContextMapperMap(Map<String,ContextMapper> contextMapperMap) {
    this.contextMapperMap = contextMapperMap;
  }
}
