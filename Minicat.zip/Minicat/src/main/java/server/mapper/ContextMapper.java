package server.mapper;

import java.util.HashMap;
import java.util.Map;

/**
 * @author aleng
 * @version 1.0.0
 * @className MappedContext
 * @description TODO
 * @createTime 2020年06月01日 19:55:00
 */
public class ContextMapper {

  private WrapperMapper wrapperMapper;

  public ContextMapper(WrapperMapper wrapperMapper) {
    this.wrapperMapper=wrapperMapper;
  }

  public WrapperMapper getWrapperMapper() {
    return wrapperMapper;
  }
}
