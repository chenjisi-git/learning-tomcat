package server.mapper;

import server.HttpServlet;

import java.util.HashMap;
import java.util.Map;

/**
 * @author aleng
 * @version 1.0.0
 * @className MappedWrapper
 * @description TODO
 * @createTime 2020年06月01日 19:55:00
 */
public class WrapperMapper {
  private Map<String, HttpServlet> servletMapperMap;

  public WrapperMapper(Map<String, HttpServlet> servletMapperMap) {
    this.servletMapperMap = servletMapperMap;
  }

  public Map<String, HttpServlet> getServletMapperMap() {
    return servletMapperMap;
  }

  public void setServletMapperMap(Map<String, HttpServlet> servletMapperMap) {
    this.servletMapperMap = servletMapperMap;
  }
}
